export const DISPLAY_SUBMIT_MESSAGE = 'DISPLAY_SUBMIT_MESSAGE'

export const displaySubmitMessage = (res) => ({ type: DISPLAY_SUBMIT_MESSAGE, res })

