'use strict'

require('babel-register')

console.log('Beginning import.')

require('./src/load_data.js').runImport()
